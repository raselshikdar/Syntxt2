// ========================================
// Public Configuration - Hard-coded values
// ========================================
// These values are safe to expose publicly
// Edit this file to update your service credentials

export const config = {
  // Clerk Authentication - Public Key
  // IMPORTANT: Replace with your real Clerk publishable key from:
  // https://dashboard.clerk.com -> API Keys -> Copy "Publishable Key"
  clerkPublishableKey: 'pk_test_YWJzdXJkLXBpZ2VvbS0zNC5jbGVyay5hY2NvdW50cy5kZXYk',

  // Cloudinary Configuration - Already configured
  cloudinary: {
    cloudName: 'djelhfrfw',
    uploadPreset: 'syntxt-next',
  },

  // App Configuration
  app: {
    name: 'syntxt_',
    description: 'A minimalist, text-only microblogging platform',
    url: typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000',
  },
} as const

// Check if Clerk is configured with a real key
export function isClerkConfigured(): boolean {
  const key = config.clerkPublishableKey
  // Check if it's not the placeholder
  return key !== 'pk_test_ZXhhbXBsZS1wbGFjZWhvbGRlcg' && 
         (key.startsWith('pk_test_') || key.startsWith('pk_live_'))
}
