// Server-side Neon Auth configuration for Next.js
// This creates the auth instance that handles all auth operations

import { createNeonAuth } from '@neondatabase/auth/next/server';

// Neon Auth configuration
// Base URL from Neon Console - Auth settings
const NEON_AUTH_BASE_URL = 'https://ep-green-fog-a184zz9k.neonauth.ap-southeast-1.aws.neon.tech/neondb';

// Create the auth instance for server-side use
export const auth = createNeonAuth({
  baseUrl: NEON_AUTH_BASE_URL,
  cookies: {
    // Secret for signing session data cookies (at least 32 characters)
    secret: process.env.NEON_AUTH_COOKIE_SECRET || 
      'neon-auth-secret-key-at-least-32-characters-long-for-security-neon-syntxt-app-2024',
    // TTL for cached session data in seconds (default: 300 = 5 minutes)
    sessionDataTtl: 86400, // 24 hours
  },
});
