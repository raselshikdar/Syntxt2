// Auth configuration for Neon Auth
// Neon Auth URL from the Neon Console

export const NEON_AUTH_CONFIG = {
  // Auth Base URL - this is the Neon Auth endpoint
  baseUrl: process.env.NEON_AUTH_BASE_URL || 
    'https://ep-green-fog-a184zz9k.neonauth.ap-southeast-1.aws.neon.tech/neondb',
  
  // Cookie secret for session management (at least 32 characters)
  cookieSecret: process.env.NEON_AUTH_COOKIE_SECRET || 
    'neon-auth-secret-key-at-least-32-characters-long-for-security-neon-syntxt-app',
    
  // Session TTL in seconds (24 hours)
  sessionDataTtl: 86400,
};

// Get the full Auth URL
export function getAuthUrl() {
  return `${NEON_AUTH_CONFIG.baseUrl}/auth`;
}

// Get the JWKS URL for JWT verification
export function getJwksUrl() {
  return `${getAuthUrl()}/.well-known/jwks.json`;
}
