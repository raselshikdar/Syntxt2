// Neon Auth Configuration
// This file exports the configuration needed for Neon Auth

// Neon Auth base URL from the Neon Console
// Format: https://<project-id>.neonauth.<region>.cloud.neon.tech/<database>
export const NEON_AUTH_BASE_URL = 
  process.env.NEON_AUTH_BASE_URL || 
  'https://ep-green-fog-a184zz9k.neonauth.ap-southeast-1.aws.neon.tech/neondb';

// Cookie secret for signing session data (at least 32 characters)
export const NEON_AUTH_COOKIE_SECRET = 
  process.env.NEON_AUTH_COOKIE_SECRET || 
  'neon-auth-secret-key-at-least-32-characters-long-for-security-neon-syntxt-app-2024';

// Session TTL in seconds (24 hours default)
export const NEON_AUTH_SESSION_TTL = 86400;
