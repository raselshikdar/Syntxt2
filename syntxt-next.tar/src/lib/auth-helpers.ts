// ========================================
// Mock Auth Helper for API Routes
// ========================================
// This replaces Clerk authentication for development/demo purposes
// In production, you would use Clerk's currentUser() instead

import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

// Get user ID from request (body or query params)
// For Mock Auth, we trust the userId sent from the client
export async function getAuthUser(request: NextRequest): Promise<{ id: string; handle: string } | null> {
  try {
    // Try to get from query params first
    const { searchParams } = new URL(request.url);
    let userId = searchParams.get('userId');

    // If not in query params, try to get from body
    if (!userId && request.method !== 'GET') {
      try {
        const body = await request.clone().json();
        userId = body?.userId;
      } catch {
        // No body or invalid JSON
      }
    }

    if (!userId) {
      return null;
    }

    // Verify user exists in database
    const user = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, handle: true },
    });

    return user;
  } catch (error) {
    console.error('Auth helper error:', error);
    return null;
  }
}

// Get user ID from request (simpler version)
export async function getAuthUserId(request: NextRequest): Promise<string | null> {
  const user = await getAuthUser(request);
  return user?.id ?? null;
}
