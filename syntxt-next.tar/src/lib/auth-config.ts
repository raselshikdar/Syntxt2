// ========================================
// Authentication Configuration
// ========================================
// Public keys are hard-coded here for easy setup
// Only CLERK_SECRET_KEY needs to be set as environment variable

export const authConfig = {
  // Clerk Publishable Key - Hard-coded (safe to expose)
  // Replace with your real key from: https://dashboard.clerk.com -> API Keys
  clerkPublishableKey: 'pk_test_c2l0ZS1hLXRoZXJtaXRlLTY3LmNsZXJrLmFjY291bnRzLmRldiQ',

  // Cloudinary Configuration - Hard-coded (safe to expose)
  cloudinary: {
    cloudName: 'djelhfrfw',
    uploadPreset: 'syntxt-next',
  },

  // Check if we have valid Clerk keys
  get isClerkConfigured() {
    const key = this.clerkPublishableKey
    // Check if it's a real-looking key (not the placeholder pattern)
    return key && key.length > 20 && key.startsWith('pk_')
  }
} as const

// Admin users - emails that get ADMIN role
export const ADMIN_EMAILS = [
  'raselshikdar597@gmail.com',
]
