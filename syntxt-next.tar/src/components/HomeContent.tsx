'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter, useSearchParams, usePathname } from 'next/navigation';
import { useAuth, useUser } from '@/components/NeonAuthProvider';
import { toast } from '@/hooks/use-toast';
import {
  Header,
  FeedSwitcher,
  PostCard,
  ComposeModal,
  ProfilePage,
  FloatingActionButton,
  BottomNav,
  SettingsPage,
  SearchPage,
  NotificationsPage,
  MessagesPage,
  ReportModal,
  AdminPanel,
  WelcomePage,
  SignInPage,
  SignUpPage,
  PostDetailsPage,
  CommentComposer,
  RepostModal,
  ScrollToTop,
  Post,
  User,
  LinkPreview,
} from '@/components/syntxt';

export function HomeContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const { isSignedIn, isLoaded, userId: authUserId, signOut } = useAuth();
  const { user: authUser } = useUser();

  // Get current view from URL
  const currentView = searchParams.get('view') || 'home';
  const authView = searchParams.get('auth');
  const profileHandle = searchParams.get('handle');
  const postId = searchParams.get('postId');

  // User state
  const [currentUserId, setCurrentUserId] = useState<string>('');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isUserSynced, setIsUserSynced] = useState(false);

  // Posts state
  const [posts, setPosts] = useState<Post[]>([]);
  const [activeFeed, setActiveFeed] = useState<'explore' | 'following'>('explore');
  const [isLoading, setIsLoading] = useState(true);

  // Navigation state for scroll
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const lastScrollY = useRef(0);
  const mainContentRef = useRef<HTMLDivElement | null>(null);
  const prevViewRef = useRef<string>(currentView);

  // Modal states
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isCommentOpen, setIsCommentOpen] = useState(false);
  const [isRepostModalOpen, setIsRepostModalOpen] = useState(false);

  // Selected post for modals
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);

  // Report state
  const [reportPostId, setReportPostId] = useState<string>('');
  const [reportUserId, setReportUserId] = useState<string>('');

  // Badge counts
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [hasViewedNotifications, setHasViewedNotifications] = useState(false);
  const [hasViewedMessages, setHasViewedMessages] = useState(false);

  const [isPublishing, setIsPublishing] = useState(false);

  // Scroll to top on view change
  useEffect(() => {
    if (prevViewRef.current !== currentView) {
      window.scrollTo({ top: 0, behavior: 'instant' });
      prevViewRef.current = currentView;
    }
  }, [currentView]);

  // Navigation helper
  const navigateTo = useCallback((view: string, params?: Record<string, string>) => {
    const urlParams = new URLSearchParams(searchParams.toString());

    if (view === 'home') {
      urlParams.delete('view');
      urlParams.delete('handle');
      urlParams.delete('postId');
    } else if (view === 'post') {
      urlParams.set('view', 'post');
    } else {
      urlParams.set('view', view);
      urlParams.delete('postId');
    }

    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value) {
          urlParams.set(key, value);
        } else {
          urlParams.delete(key);
        }
      });
    }

    const queryString = urlParams.toString();
    router.push(queryString ? `${pathname}?${queryString}` : pathname);
  }, [router, searchParams, pathname]);

  // Clear auth params
  const clearAuthParams = useCallback(() => {
    const urlParams = new URLSearchParams(searchParams.toString());
    urlParams.delete('auth');
    const queryString = urlParams.toString();
    router.push(queryString ? `${pathname}?${queryString}` : pathname);
  }, [router, searchParams, pathname]);

  // Sync user with database when signed in
  useEffect(() => {
    const syncUser = async () => {
      if (!isSignedIn || !authUserId) {
        setIsUserSynced(false);
        setCurrentUserId('');
        setCurrentUser(null);
        return;
      }

      try {
        // Sync user with our database
        const res = await fetch('/api/users/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            neonAuthId: authUserId,
            email: authUser?.email,
            handle: authUser?.email?.split('@')[0]?.toLowerCase().replace(/[^a-z0-9_]/g, '') || undefined,
            displayName: authUser?.name || undefined,
          }),
        });
        const userData = await res.json();

        if (userData.id) {
          setCurrentUserId(userData.id);
          setCurrentUser(userData);
          setIsUserSynced(true);
        } else if (userData.error) {
          console.error('User sync error:', userData.error);
        }
      } catch (error) {
        console.error('User sync error:', error);
      }
    };

    if (isLoaded) {
      syncUser();
    }
  }, [isSignedIn, isLoaded, authUserId, authUser]);

  // Fetch posts when feed or user changes
  useEffect(() => {
    const fetchPosts = async () => {
      if (!isUserSynced || currentView !== 'home') return;

      setIsLoading(true);
      try {
        const res = await fetch(`/api/posts?feed=${activeFeed}&userId=${currentUserId || ''}`);
        const data = await res.json();
        setPosts(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error('Fetch posts error:', error);
      }
      setIsLoading(false);
    };

    fetchPosts();
  }, [activeFeed, currentUserId, isUserSynced, currentView]);

  // Fetch badge counts
  useEffect(() => {
    if (!currentUserId || !isUserSynced) return;

    const fetchBadges = async () => {
      try {
        const [notifRes, msgRes] = await Promise.all([
          fetch(`/api/notifications?userId=${currentUserId}&countOnly=true`),
          fetch(`/api/messages?userId=${currentUserId}&countOnly=true`),
        ]);
        const notifData = await notifRes.json();
        const msgData = await msgRes.json();

        if (!hasViewedNotifications) {
          setUnreadNotifications(notifData.count || 0);
        }
        if (!hasViewedMessages) {
          setUnreadMessages(msgData.count || 0);
        }
      } catch (error) {
        console.error('Error fetching badges:', error);
      }
    };

    fetchBadges();
    const interval = setInterval(fetchBadges, 30000);
    return () => clearInterval(interval);
  }, [currentUserId, isUserSynced, hasViewedNotifications, hasViewedMessages]);

  // Handle scroll for header visibility
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;

      if (scrollY > lastScrollY.current && scrollY > 50) {
        setIsHeaderVisible(false);
      } else if (scrollY < lastScrollY.current) {
        setIsHeaderVisible(true);
      }

      lastScrollY.current = scrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle tab change from bottom nav
  const handleTabChange = (tab: string) => {
    if (tab === 'home') {
      navigateTo('home');
    } else {
      navigateTo(tab);
    }
  };

  // Handle user click to open profile
  const handleUserClick = (handle: string) => {
    navigateTo('profile', { handle });
  };

  // Handle post click to open post details
  const handlePostClick = (postId: string) => {
    navigateTo('post', { postId });
  };

  // Handle like
  const handleLike = async (postId: string) => {
    if (!currentUserId) return;

    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    try {
      if (post.isLiked) {
        const res = await fetch(`/api/likes?postId=${postId}&userId=${currentUserId}`, {
          method: 'DELETE',
        });
        const data = await res.json();
        setPosts((prev) =>
          prev.map((p) =>
            p.id === postId ? { ...p, isLiked: false, likesCount: data.likesCount || 0 } : p
          )
        );
      } else {
        const res = await fetch('/api/likes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ postId, userId: currentUserId }),
        });
        const data = await res.json();
        setPosts((prev) =>
          prev.map((p) =>
            p.id === postId ? { ...p, isLiked: true, likesCount: data.likesCount || 1 } : p
          )
        );
      }
    } catch (error) {
      console.error('Like error:', error);
    }
  };

  // Handle bookmark
  const handleBookmark = async (postId: string) => {
    if (!currentUserId) return;

    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    try {
      if (post.isBookmarked) {
        await fetch(`/api/bookmarks?postId=${postId}&userId=${currentUserId}`, {
          method: 'DELETE',
        });
        setPosts((prev) =>
          prev.map((p) => (p.id === postId ? { ...p, isBookmarked: false } : p))
        );
        toast({ title: 'Removed from bookmarks' });
      } else {
        await fetch('/api/bookmarks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ postId, userId: currentUserId }),
        });
        setPosts((prev) =>
          prev.map((p) => (p.id === postId ? { ...p, isBookmarked: true } : p))
        );
        toast({ title: 'Saved to bookmarks' });
      }
    } catch (error) {
      console.error('Bookmark error:', error);
    }
  };

  // Handle repost - opens repost modal
  const handleRepost = (postId: string) => {
    const post = posts.find((p) => p.id === postId);
    if (post) {
      setSelectedPost(post);
      setIsRepostModalOpen(true);
    }
  };

  // Handle repost callback from modal
  const handleRepostCallback = (postId: string, isReposted: boolean) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              isReposted,
              repostsCount: isReposted ? p.repostsCount + 1 : Math.max(0, p.repostsCount - 1),
            }
          : p
      )
    );
  };

  // Handle quote post callback
  const handleQuotePost = async (postId: string, quoteContent: string) => {
    if (!currentUserId) return;

    try {
      const res = await fetch('/api/reposts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          postId,
          userId: currentUserId,
          isQuote: true,
          quoteContent,
        }),
      });
      const data = await res.json();

      if (data.post) {
        setPosts((prev) => [data.post, ...prev]);
      }
    } catch (error) {
      console.error('Quote post error:', error);
    }
  };

  // Handle comment - opens comment modal
  const handleComment = (postId: string) => {
    const post = posts.find((p) => p.id === postId);
    if (post) {
      setSelectedPost(post);
      setIsCommentOpen(true);
    }
  };

  // Handle comment submit
  const handleCommentSubmit = async (postId: string, content: string, imageUrl?: string) => {
    if (!currentUserId) return;

    try {
      const res = await fetch(`/api/posts/${postId}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content,
          authorId: currentUserId,
          imageUrl,
        }),
      });

      if (res.ok) {
        setPosts((prev) =>
          prev.map((p) =>
            p.id === postId ? { ...p, repliesCount: (p.repliesCount || 0) + 1 } : p
          )
        );
      }
    } catch (error) {
      console.error('Comment error:', error);
      throw error;
    }
  };

  // Handle report
  const handleReport = (postId: string) => {
    const post = posts.find((p) => p.id === postId);
    if (post) {
      setReportPostId(postId);
      setReportUserId(post.author.id);
      setIsReportOpen(true);
    }
  };

  // Handle delete post
  const handleDeletePost = async (postId: string) => {
    try {
      await fetch(`/api/posts?postId=${postId}`, {
        method: 'DELETE',
      });
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      toast({ title: 'Post deleted' });
    } catch (error) {
      console.error('Delete error:', error);
      toast({ title: 'Error deleting post', variant: 'destructive' });
    }
  };

  // Handle publish new post
  const handlePublish = async (content: string, imageUrl?: string, linkPreview?: LinkPreview) => {
    if (!currentUserId) return;

    setIsPublishing(true);
    try {
      const res = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content,
          authorId: currentUserId,
          imageUrl,
          linkUrl: linkPreview?.url,
          linkTitle: linkPreview?.title,
          linkDesc: linkPreview?.description,
          linkImage: linkPreview?.image,
        }),
      });
      const newPost = await res.json();

      if (newPost.id) {
        setPosts((prev) => [newPost, ...prev]);
        setIsComposeOpen(false);
        toast({ title: 'Post published!' });
      } else if (newPost.error) {
        toast({
          title: 'Error',
          description: newPost.error,
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Publish error:', error);
      toast({
        title: 'Error',
        description: 'Failed to publish post',
        variant: 'destructive',
      });
    }
    setIsPublishing(false);
  };

  // Handle follow/unfollow callbacks
  const handleFollow = async (userId: string) => {
    if (!currentUserId) return;
    try {
      await fetch('/api/follows', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ followerId: currentUserId, followingId: userId }),
      });
    } catch (error) {
      console.error('Follow error:', error);
    }
  };

  const handleUnfollow = async (userId: string) => {
    if (!currentUserId) return;
    try {
      await fetch(`/api/follows?followerId=${currentUserId}&followingId=${userId}`, {
        method: 'DELETE',
      });
    } catch (error) {
      console.error('Unfollow error:', error);
    }
  };

  // Handle user update from settings
  const handleUserUpdate = (user: User) => {
    setCurrentUser(user);
  };

  // Handle notification read
  const handleNotificationRead = () => {
    setUnreadNotifications((prev) => Math.max(0, prev - 1));
  };

  // Handle message read
  const handleMessageRead = () => {
    setUnreadMessages((prev) => Math.max(0, prev - 1));
  };

  // Handle notifications viewed
  const handleNotificationsViewed = () => {
    setHasViewedNotifications(true);
    setUnreadNotifications(0);
  };

  // Handle messages viewed
  const handleMessagesViewed = () => {
    setHasViewedMessages(true);
    setUnreadMessages(0);
  };

  // Handle sign in success
  const handleSignInSuccess = () => {
    clearAuthParams();
    window.location.reload();
  };

  // Handle sign up success
  const handleSignUpSuccess = () => {
    clearAuthParams();
    window.location.reload();
  };

  // Check if user can access admin panel
  const canAccessAdmin = currentUser?.role === 'ADMIN' || currentUser?.role === 'MODERATOR';

  // Show loading state while checking auth
  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-pulse text-lg font-medium">Loading syntxt_</div>
        </div>
      </div>
    );
  }

  // Auth pages for non-authenticated users
  if (!isSignedIn) {
    if (authView === 'signin') {
      return (
        <SignInPage onBack={clearAuthParams} onSignInSuccess={handleSignInSuccess} />
      );
    }

    if (authView === 'signup') {
      return (
        <SignUpPage onBack={clearAuthParams} onSignUpSuccess={handleSignUpSuccess} />
      );
    }

    // Welcome page (default for non-authenticated)
    return (
      <WelcomePage
        onSignIn={() => {
          const urlParams = new URLSearchParams(searchParams.toString());
          urlParams.set('auth', 'signin');
          router.push(`${pathname}?${urlParams.toString()}`);
        }}
        onSignUp={() => {
          const urlParams = new URLSearchParams(searchParams.toString());
          urlParams.set('auth', 'signup');
          router.push(`${pathname}?${urlParams.toString()}`);
        }}
      />
    );
  }

  // Show loading while syncing user
  if (!isUserSynced) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-pulse text-lg font-medium">Syncing your data...</div>
        </div>
      </div>
    );
  }

  // Render page based on current view
  const renderPage = () => {
    switch (currentView) {
      case 'profile':
        return (
          <ProfilePage
            userHandle={profileHandle || currentUser?.handle || ''}
            currentUserId={currentUserId}
            onUserClick={handleUserClick}
            onLike={handleLike}
            onBookmark={handleBookmark}
            onRepost={handleRepost}
            onFollow={handleFollow}
            onUnfollow={handleUnfollow}
            onBack={() => navigateTo('home')}
            onEditProfile={() => navigateTo('settings')}
          />
        );

      case 'post':
        return (
          <PostDetailsPage
            postId={postId || ''}
            currentUserId={currentUserId}
            onBack={() => navigateTo('home')}
            onUserClick={handleUserClick}
            onLike={handleLike}
            onBookmark={handleBookmark}
            onRepost={handleRepost}
          />
        );

      case 'search':
        return (
          <SearchPage
            currentUserId={currentUserId}
            onUserClick={handleUserClick}
            onLike={handleLike}
            onBookmark={handleBookmark}
            onRepost={handleRepost}
            onBack={() => navigateTo('home')}
          />
        );

      case 'messages':
        return (
          <MessagesPage
            currentUserId={currentUserId}
            onUserClick={handleUserClick}
            onMessageRead={handleMessageRead}
            onViewed={handleMessagesViewed}
            onBack={() => navigateTo('home')}
          />
        );

      case 'notifications':
        return (
          <NotificationsPage
            currentUserId={currentUserId}
            onUserClick={handleUserClick}
            onNotificationRead={handleNotificationRead}
            onViewed={handleNotificationsViewed}
            onBack={() => navigateTo('home')}
          />
        );

      case 'settings':
        return (
          <SettingsPage
            currentUser={currentUser}
            onUserUpdate={handleUserUpdate}
            onBack={() => navigateTo('home')}
            onSignOut={signOut}
          />
        );

      default:
        // Home page
        return (
          <>
            {/* Feed Switcher - scrolls with content */}
            <FeedSwitcher activeFeed={activeFeed} onFeedChange={setActiveFeed} />

            {/* Posts */}
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="border border-border rounded-md p-4 animate-pulse">
                    <div className="h-4 bg-muted rounded w-24 mb-3" />
                    <div className="h-4 bg-muted rounded w-full mb-2" />
                    <div className="h-4 bg-muted rounded w-3/4 mb-4" />
                    <div className="h-8 bg-muted rounded w-full" />
                  </div>
                ))}
              </div>
            ) : posts.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-4xl mb-4">📝</div>
                <p className="text-muted-foreground">
                  {activeFeed === 'following'
                    ? 'No posts from people you follow yet. Try exploring!'
                    : 'No posts yet. Be the first to share something!'}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {posts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    currentUserId={currentUserId}
                    onUserClick={handleUserClick}
                    onLike={handleLike}
                    onBookmark={handleBookmark}
                    onRepost={handleRepost}
                    onDelete={handleDeletePost}
                    onReport={handleReport}
                    onComment={handleComment}
                    onPostClick={handlePostClick}
                  />
                ))}
              </div>
            )}
          </>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header - only shown on home page */}
      {currentView === 'home' && (
        <div
          className={`sticky top-0 z-40 transition-transform duration-300 ${isHeaderVisible ? 'translate-y-0' : '-translate-y-full'}`}
        >
          <Header
            currentUserHandle={currentUser?.handle || ''}
            onUserClick={() => {
              if (currentUser?.handle) {
                handleUserClick(currentUser.handle);
              }
            }}
            onSignOut={signOut}
          />
        </div>
      )}

      {/* Main Content - scrollable */}
      <main
        ref={mainContentRef}
        className={`flex-1 container max-w-2xl mx-auto px-4 pb-20 ${currentView !== 'home' ? 'pt-0' : 'pt-2'}`}
      >
        {renderPage()}
      </main>

      {/* Scroll to top button - only on home page */}
      {currentView === 'home' && <ScrollToTop />}

      {/* Floating Action Button */}
      <FloatingActionButton onClick={() => setIsComposeOpen(true)} />

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={currentView}
        onTabChange={handleTabChange}
        unreadMessages={unreadMessages}
        unreadNotifications={unreadNotifications}
      />

      {/* Compose Modal */}
      <ComposeModal
        isOpen={isComposeOpen}
        onClose={() => setIsComposeOpen(false)}
        onPublish={handlePublish}
        isPublishing={isPublishing}
      />

      {/* Comment Composer Modal */}
      <CommentComposer
        isOpen={isCommentOpen}
        onClose={() => {
          setIsCommentOpen(false);
          setSelectedPost(null);
        }}
        post={selectedPost}
        currentUserId={currentUserId}
        onComment={handleCommentSubmit}
      />

      {/* Repost Modal */}
      <RepostModal
        isOpen={isRepostModalOpen}
        onClose={() => {
          setIsRepostModalOpen(false);
          setSelectedPost(null);
        }}
        post={selectedPost}
        currentUserId={currentUserId}
        onRepost={handleRepostCallback}
        onQuotePost={handleQuotePost}
      />

      {/* Report Modal */}
      <ReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        postId={reportPostId}
        reportedUserId={reportUserId}
        currentUserId={currentUserId}
      />

      {/* Admin Panel */}
      {canAccessAdmin && (
        <AdminPanel isOpen={isAdminOpen} onClose={() => setIsAdminOpen(false)} currentUser={currentUser} />
      )}
    </div>
  );
}
