'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import { ArrowLeft, Mail, Loader2, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';

// Verification Page for Email Code Verification
// After sign-up, user enters the 6-digit code sent to their email
interface VerificationPageProps {
  email: string;
  displayName: string;
  username: string;
  password?: string;
  mode: 'signup' | 'forgot-password';
  onBack: () => void;
  onVerified: () => void;
}

export function VerificationPage({
  email,
  displayName,
  username,
  mode,
  onBack,
  onVerified,
}: VerificationPageProps) {
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [verified, setVerified] = useState(false);
  const [countdown, setCountdown] = useState(60);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Countdown timer for resend
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  // Focus first input on mount
  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  // Verify the code - declared first since it's used by handleCodeChange
  const handleVerify = useCallback(async (codeToVerify: string) => {
    if (!codeToVerify || codeToVerify.length !== 6) return;
    
    setIsLoading(true);
    setError(null);

    try {
      if (mode === 'signup') {
        // Verify email with Neon Auth OTP
        const response = await fetch('/api/auth/email-otp/verify-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            email: email,
            otp: codeToVerify,
          }),
        });

        const data = await response.json();

        if (response.ok) {
          // Now create the user in our database with username and display name
          if (username && displayName) {
            await fetch('/api/users/sync', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                neonAuthId: data.user?.id,
                email: email,
                handle: username,
                displayName: displayName,
              }),
            });
          }
          
          setVerified(true);
          toast({ title: 'Email verified successfully!' });
          setTimeout(() => {
            onVerified();
          }, 1500);
        } else {
          setError(data.error || data.message || 'Invalid verification code');
          setCode(['', '', '', '', '', '']);
          inputRefs.current[0]?.focus();
        }
      } else {
        // Forgot password verification - verify the OTP
        const response = await fetch('/api/auth/email-otp/verify-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            email: email,
            otp: codeToVerify,
          }),
        });

        const data = await response.json();

        if (response.ok) {
          setVerified(true);
          toast({ title: 'Email verified! You can now reset your password.' });
          setTimeout(() => {
            onVerified();
          }, 1500);
        } else {
          setError(data.error || data.message || 'Invalid verification code');
          setCode(['', '', '', '', '', '']);
          inputRefs.current[0]?.focus();
        }
      }
    } catch (err) {
      console.error('Verification error:', err);
      setError('Failed to verify code. Please try again.');
      setCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    }
    setIsLoading(false);
  }, [email, username, displayName, mode, onVerified]);

  // Handle code input change
  const handleCodeChange = useCallback((index: number, value: string) => {
    const digit = value.replace(/\D/g, '').slice(-1);
    setCode(prevCode => {
      const newCode = [...prevCode];
      newCode[index] = digit;
      
      // Auto-submit when all digits entered
      if (newCode.every(d => d) && newCode.join('').length === 6) {
        // Use setTimeout to ensure state is updated before calling handleVerify
        setTimeout(() => {
          handleVerify(newCode.join(''));
        }, 0);
      }
      
      return newCode;
    });
    setError(null);

    // Auto-focus next input
    if (digit && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  }, [handleVerify]);

  // Handle key down for backspace navigation
  const handleKeyDown = useCallback((index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  }, [code]);

  // Handle paste
  const handlePaste = useCallback((e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    const newCode = [...code];
    pastedData.split('').forEach((char, i) => {
      if (i < 6) newCode[i] = char;
    });
    setCode(newCode);
    
    // Focus last filled input or first empty
    const lastIndex = Math.min(pastedData.length - 1, 5);
    inputRefs.current[lastIndex]?.focus();
    
    // Auto-submit if all digits pasted
    if (newCode.every(d => d) && newCode.join('').length === 6) {
      setTimeout(() => {
        handleVerify(newCode.join(''));
      }, 0);
    }
  }, [code, handleVerify]);

  // Resend verification code
  const handleResend = useCallback(async () => {
    setIsResending(true);
    setError(null);

    try {
      const response = await fetch('/api/auth/email-otp/send-verification-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (response.ok) {
        toast({ title: 'Verification code resent!' });
        setCountdown(60);
        setCode(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();
      } else {
        setError(data.error || 'Failed to resend code');
      }
    } catch (err) {
      console.error('Resend error:', err);
      setError('Failed to resend code');
    }
    setIsResending(false);
  }, [email]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur">
        <div className="container max-w-2xl mx-auto px-4 h-14 flex items-center">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="btn-bounce h-8 w-8 mr-2"
            disabled={isLoading}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-lg font-semibold">
            {verified ? 'Verified!' : 'Verify Email'}
          </h1>
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-sm">
          {/* Logo */}
          <div className="text-center mb-8">
            {verified ? (
              <>
                <CheckCircle className="w-12 h-12 mx-auto text-green-500 mb-3" />
                <h2 className="text-xl font-semibold">Email Verified!</h2>
                <p className="text-muted-foreground text-sm mt-1">
                  Redirecting...
                </p>
              </>
            ) : (
              <>
                <Mail className="w-12 h-12 mx-auto text-primary mb-3" />
                <h2 className="text-xl font-semibold">Check your email</h2>
                <p className="text-muted-foreground text-sm mt-1">
                  We sent a 6-digit code to
                </p>
                <p className="font-medium text-sm">{email}</p>
              </>
            )}
          </div>

          {!verified && (
            <>
              {/* Code Input */}
              <div className="space-y-4">
                <div className="flex justify-center gap-2">
                  {code.map((digit, index) => (
                    <Input
                      key={index}
                      ref={(el) => { inputRefs.current[index] = el; }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleCodeChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      onPaste={handlePaste}
                      className="w-12 h-14 text-center text-2xl font-semibold"
                      disabled={isLoading}
                    />
                  ))}
                </div>

                {error && (
                  <div className="text-sm text-destructive text-center">{error}</div>
                )}

                <Button
                  onClick={() => handleVerify(code.join(''))}
                  disabled={isLoading || code.some(d => !d)}
                  className="w-full btn-bounce"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Verifying...
                    </>
                  ) : (
                    'Verify Email'
                  )}
                </Button>
              </div>

              {/* Resend */}
              <div className="text-center mt-6">
                <p className="text-sm text-muted-foreground mb-2">
                  Didn&apos;t receive the code?
                </p>
                <Button
                  variant="ghost"
                  onClick={handleResend}
                  disabled={countdown > 0 || isResending}
                  className="text-sm"
                >
                  {isResending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Resending...
                    </>
                  ) : countdown > 0 ? (
                    `Resend in ${countdown}s`
                  ) : (
                    'Resend Code'
                  )}
                </Button>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
