'use client';

import { ReactNode, createContext, useContext, useEffect, useState, useCallback } from 'react';

// ========================================
// Types
// ========================================
interface AuthUser {
  id: string;
  email: string;
  name?: string | null;
  emailVerified?: boolean;
  image?: string | null;
  createdAt?: Date;
  updatedAt?: Date;
}

interface AuthSession {
  id: string;
  userId: string;
  expiresAt: Date;
  createdAt?: Date;
  updatedAt?: Date;
}

interface SessionData {
  user: AuthUser | null;
  session: AuthSession | null;
}

interface AuthContextType {
  isSignedIn: boolean;
  isLoaded: boolean;
  userId: string | null;
  user: AuthUser | null;
  session: AuthSession | null;
  signOut: () => Promise<void>;
  refreshSession: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  isSignedIn: false,
  isLoaded: false,
  userId: null,
  user: null,
  session: null,
  signOut: async () => {},
  refreshSession: async () => {},
});

export const useAuthContext = () => useContext(AuthContext);

// ========================================
// Neon Auth Provider
// ========================================
export function NeonAuthProvider({ children }: { children: ReactNode }) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [sessionData, setSessionData] = useState<SessionData>({ user: null, session: null });

  // Fetch session from our API proxy
  const fetchSession = useCallback(async () => {
    try {
      const response = await fetch('/api/auth/get-session', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setSessionData({
          user: data.user || null,
          session: data.session || null,
        });
      } else {
        setSessionData({ user: null, session: null });
      }
    } catch (error) {
      console.error('Failed to fetch session:', error);
      setSessionData({ user: null, session: null });
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    fetchSession();
  }, [fetchSession]);

  const signOut = useCallback(async () => {
    try {
      await fetch('/api/auth/sign-out', {
        method: 'POST',
        credentials: 'include',
      });
      setSessionData({ user: null, session: null });
      window.location.href = '/';
    } catch (error) {
      console.error('Sign out error:', error);
    }
  }, []);

  const refreshSession = useCallback(async () => {
    await fetchSession();
  }, [fetchSession]);

  const user = sessionData.user;
  const userId = user?.id ?? null;
  const session = sessionData.session;
  const isSignedIn = user !== null;

  return (
    <AuthContext.Provider
      value={{
        isSignedIn,
        isLoaded,
        userId,
        user,
        session,
        signOut,
        refreshSession,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// ========================================
// Export hooks for compatibility
// ========================================
export function useAuth() {
  const context = useAuthContext();
  return {
    isSignedIn: context.isSignedIn,
    isLoaded: context.isLoaded,
    userId: context.userId,
    signOut: context.signOut,
  };
}

export function useUser() {
  const context = useAuthContext();
  return {
    isSignedIn: context.isSignedIn,
    isLoaded: context.isLoaded,
    user: context.user,
  };
}

export function useSession() {
  const context = useAuthContext();
  return {
    isSignedIn: context.isSignedIn,
    isLoaded: context.isLoaded,
    session: context.session,
    user: context.user,
  };
}
