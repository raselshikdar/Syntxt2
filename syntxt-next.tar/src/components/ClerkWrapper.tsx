'use client'

import { ReactNode, createContext, useContext, useSyncExternalStore, useCallback } from 'react'

// ========================================
// Hardcoded Public Keys
// ========================================
const CLERK_PUBLISHABLE_KEY = 'pk_test_YWJzdXJkLXBpZ2VvbS0zNC5jbGVyay5hY2NvdW50cy5kZXYk'

// ========================================
// Auth Context Type
// ========================================
interface AuthUser {
  id: string
  username?: string | null
  fullName?: string | null
  imageUrl?: string
  emailAddresses?: Array<{ emailAddress: string }>
  primaryEmailAddress?: { emailAddress: string }
}

interface AuthContextType {
  isSignedIn: boolean
  isLoaded: boolean
  userId: string | null
  user: AuthUser | null
  signOut: () => void
  openSignIn?: () => void
}

const AuthContext = createContext<AuthContextType>({
  isSignedIn: false,
  isLoaded: false,
  userId: null,
  user: null,
  signOut: () => {},
})

export const useAuthContext = () => useContext(AuthContext)

// ========================================
// Local Storage Mock Auth
// ========================================
const AUTH_STORAGE_KEY = 'syntxt_mock_auth'

interface StoredAuth {
  userId: string
  user: AuthUser
}

// Server snapshot for SSR - always returns null
function getServerSnapshot(): StoredAuth | null {
  return null
}

// Client snapshot - reads from localStorage
function getClientSnapshot(): StoredAuth | null {
  try {
    const stored = localStorage.getItem(AUTH_STORAGE_KEY)
    if (stored) {
      return JSON.parse(stored)
    }
  } catch {
    // Ignore errors
  }
  return null
}

// Subscribe to storage changes (for multi-tab sync)
function subscribe(callback: () => void) {
  const handleStorageChange = (e: StorageEvent) => {
    if (e.key === AUTH_STORAGE_KEY) {
      callback()
    }
  }
  window.addEventListener('storage', handleStorageChange)
  return () => window.removeEventListener('storage', handleStorageChange)
}

function setStoredAuth(data: StoredAuth | null) {
  if (typeof window === 'undefined') return
  try {
    if (data) {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(data))
    } else {
      localStorage.removeItem(AUTH_STORAGE_KEY)
    }
  } catch {
    // Ignore errors
  }
}

// ========================================
// Auth Provider with Mock Auth
// ========================================
export function ClerkWrapper({ children }: { children: ReactNode }) {
  // Use useSyncExternalStore for localStorage - SSR safe
  const storedAuth = useSyncExternalStore(subscribe, getClientSnapshot, getServerSnapshot)
  
  // Derive state from stored auth
  const isSignedIn = storedAuth !== null
  const isLoaded = typeof window !== 'undefined' // Always loaded on client
  const userId = storedAuth?.userId ?? null
  const user = storedAuth?.user ?? null

  // Sign out
  const signOut = useCallback(() => {
    setStoredAuth(null)
    window.location.href = '/'
  }, [])

  return (
    <AuthContext.Provider
      value={{
        isSignedIn,
        isLoaded,
        userId,
        user,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

// Export hooks for compatibility
export function useAuth() {
  const context = useAuthContext()
  return {
    isSignedIn: context.isSignedIn,
    isLoaded: context.isLoaded,
    userId: context.userId,
    signOut: context.signOut,
  }
}

export function useUser() {
  const context = useAuthContext()
  return {
    isSignedIn: context.isSignedIn,
    isLoaded: context.isLoaded,
    user: context.user,
  }
}

// Export handleSignIn and handleSignUp for SignInPage and SignUpPage
export function useAuthActions() {
  const context = useAuthContext()
  
  const signIn = useCallback(async (email: string, password: string) => {
    // This will be called from SignInPage
    const res = await fetch('/api/users/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        handle: email.split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, ''),
        displayName: email.split('@')[0],
        email: email,
      }),
    })
    
    const userData = await res.json()
    
    if (userData.id) {
      const authUser: AuthUser = {
        id: userData.id,
        username: userData.handle,
        fullName: userData.displayName,
        emailAddresses: [{ emailAddress: email }],
        primaryEmailAddress: { emailAddress: email },
      }
      
      setStoredAuth({ userId: userData.id, user: authUser })
      window.location.reload()
      return { success: true }
    }
    
    return { success: false, error: userData.error || 'Failed to sign in' }
  }, [])
  
  const signUp = useCallback(async (email: string, password: string, handle?: string, displayName?: string) => {
    const finalHandle = handle || email.split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, '')
    
    const res = await fetch('/api/users/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        handle: finalHandle,
        displayName: displayName || undefined,
        email: email,
      }),
    })
    
    const userData = await res.json()
    
    if (userData.id) {
      const authUser: AuthUser = {
        id: userData.id,
        username: userData.handle,
        fullName: userData.displayName,
        emailAddresses: [{ emailAddress: email }],
        primaryEmailAddress: { emailAddress: email },
      }
      
      setStoredAuth({ userId: userData.id, user: authUser })
      window.location.reload()
      return { success: true }
    }
    
    return { success: false, error: userData.error || 'Failed to create account' }
  }, [])
  
  return { signIn, signUp, signOut: context.signOut }
}
