import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Create or sync user
// Called after sign-up/sign-in to ensure user exists in our database
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const { handle, displayName, email, neonAuthId } = body;

    // Use Neon Auth ID as the unique identifier
    if (!neonAuthId) {
      return NextResponse.json({ error: 'Neon Auth ID is required' }, { status: 400 });
    }

    // Check if user exists by Neon Auth ID
    let existingUser = await db.user.findFirst({
      where: {
        OR: [
          { clerkId: neonAuthId }, // We store Neon Auth ID in clerkId field for compatibility
          ...(email ? [{ email: email }] : []),
        ],
      },
    });

    // Generate handle from email if not provided
    let validatedHandle = handle;
    if (!validatedHandle && email) {
      validatedHandle = email.split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, '');
    }
    if (!validatedHandle) {
      validatedHandle = `user_${neonAuthId.slice(-8)}`;
    }

    // Validate handle format
    validatedHandle = validatedHandle.toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (validatedHandle.length < 1 || validatedHandle.length > 20) {
      validatedHandle = validatedHandle.slice(0, 20);
    }

    // Ensure handle is unique
    if (!existingUser) {
      const handleExists = await db.user.findUnique({
        where: { handle: validatedHandle },
      });
      if (handleExists) {
        validatedHandle = `${validatedHandle}_${Date.now().toString(36).slice(-4)}`;
      }
    }

    if (existingUser) {
      // Update existing user
      const updatedUser = await db.user.update({
        where: { id: existingUser.id },
        data: {
          handle: validatedHandle,
          displayName: displayName || existingUser.displayName,
          email: email || existingUser.email,
          clerkId: neonAuthId, // Update with Neon Auth ID
        },
      });
      return NextResponse.json(updatedUser);
    }

    // Create new user
    const newUser = await db.user.create({
      data: {
        clerkId: neonAuthId, // Store Neon Auth ID in clerkId field for compatibility
        handle: validatedHandle,
        displayName: displayName || null,
        email: email || null,
      },
    });

    return NextResponse.json(newUser);
  } catch (error) {
    console.error('User sync error:', error);
    return NextResponse.json({ error: 'Failed to sync user' }, { status: 500 });
  }
}

// GET - Get current user
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const neonAuthId = searchParams.get('neonAuthId');

    if (userId) {
      const user = await db.user.findUnique({
        where: { id: userId },
      });
      if (!user) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }
      return NextResponse.json(user);
    }

    if (neonAuthId) {
      const user = await db.user.findFirst({
        where: { clerkId: neonAuthId },
      });
      if (!user) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }
      return NextResponse.json(user);
    }

    return NextResponse.json({ error: 'userId or neonAuthId is required' }, { status: 400 });
  } catch (error) {
    console.error('Get user error:', error);
    return NextResponse.json({ error: 'Failed to get user' }, { status: 500 });
  }
}
