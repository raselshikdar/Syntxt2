import { NextRequest, NextResponse } from 'next/server';

// OAuth callback handler - for Mock Auth, just redirect to home
// In production with Clerk, this would sync user with database after OAuth login
export async function GET(request: NextRequest) {
  // For Mock Auth, just redirect to home
  return NextResponse.redirect(new URL('/', request.url));
}
