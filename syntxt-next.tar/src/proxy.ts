import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Next.js 16.1.3 uses proxy.ts instead of middleware.ts
// Simple proxy for handling requests
export function proxy(request: NextRequest) {
  const response = NextResponse.next()
  
  // Add security headers
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('X-Content-Type-Options', 'nosniff')
  
  return response
}

export const config = {
  matcher: [
    // Skip Next.js internals and all static files
    '/((?!_next/static|_next/image|favicon.ico|public/|api/).*)',
  ],
}
